package com.atharmedia.contactsmanager

import android.Manifest
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class ContactItem(
    val contactId: Long,
    val name: String,
    val rawNumbers: List<String>,
    val distinctCores: List<String>
)

data class DuplicateGroup(
    val normalizedName: String,
    val contacts: List<ContactItem>
)

class MainActivity : AppCompatActivity() {

    private lateinit var etCode1: EditText
    private lateinit var etCode2: EditText
    private lateinit var tvStats: TextView
    private lateinit var tabLayout: TabLayout
    private lateinit var btnApplyAllSingle: Button
    private lateinit var recyclerView: RecyclerView

    private val duplicateGroups = mutableListOf<DuplicateGroup>()
    private val multiNumberContacts = mutableListOf<ContactItem>()
    private val singleNumberUnformatted = mutableListOf<ContactItem>()
    private var skippedCompliantCount = 0
    private var currentTab = 0

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.READ_CONTACTS] == true &&
            perms[Manifest.permission.WRITE_CONTACTS] == true
        ) {
            scanContacts()
        } else {
            Toast.makeText(this, "يجب منح صلاحية الوصول وتعديل جهات الاتصال", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCode1 = findViewById(R.id.etCode1)
        etCode2 = findViewById(R.id.etCode2)
        tvStats = findViewById(R.id.tvStats)
        tabLayout = findViewById(R.id.tabLayout)
        btnApplyAllSingle = findViewById(R.id.btnApplyAllSingle)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        findViewById<Button>(R.id.btnScan).setOnClickListener { checkPermissionsAndScan() }
        findViewById<Button>(R.id.btnBackup).setOnClickListener { exportVcfBackup() }

        btnApplyAllSingle.setOnClickListener {
            val c1 = formatCode(etCode1.text.toString())
            val c2 = formatCode(etCode2.text.toString())
            var updated = 0
            for (contact in singleNumberUnformatted.toList()) {
                val core = contact.distinctCores.firstOrNull() ?: continue
                if (applyThreeFormatsToContact(contact.contactId, core, c1, c2)) {
                    updated++
                }
            }
            Toast.makeText(this, "تم تحديث $updated جهة اتصال بالصيغ الثلاث", Toast.LENGTH_LONG).show()
            scanContacts()
        }

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTab = tab.position
                refreshList()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun checkPermissionsAndScan() {
        val readGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val writeGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (readGranted && writeGranted) {
            scanContacts()
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS))
        }
    }

    private fun formatCode(raw: String): String {
        val cleaned = normalizeDigits(raw).replace(Regex("[^0-9+]"), "")
        return if (cleaned.startsWith("+")) cleaned else "+$cleaned"
    }

    private fun normalizeDigits(input: String): String {
        val arabic = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val english = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
        var out = input
        for (i in arabic.indices) {
            out = out.replace(arabic[i], english[i])
        }
        return out
    }

    private fun cleanPhoneString(raw: String): String {
        var s = normalizeDigits(raw)
            .replace(Regex("[\\s\\-()\\u200E\\u200F\\u202A-\\u202E]"), "")
        if (s.startsWith("00")) s = "+" + s.substring(2)
        return s
    }

    private fun extractCoreNumber(raw: String, code1: String, code2: String): String {
        val s = cleanPhoneString(raw)
        val digits1 = code1.removePrefix("+")
        val digits2 = code2.removePrefix("+")

        return when {
            s.startsWith(code1) && s.length > code1.length + 4 -> s.removePrefix(code1).trimStart('0')
            s.startsWith(digits1) && s.length > digits1.length + 4 -> s.removePrefix(digits1).trimStart('0')
            s.startsWith(code2) && s.length > code2.length + 4 -> s.removePrefix(code2).trimStart('0')
            s.startsWith(digits2) && s.length > digits2.length + 4 -> s.removePrefix(digits2).trimStart('0')
            s.startsWith("+") -> s
            s.startsWith("0") -> s.trimStart('0')
            else -> s
        }
    }

    private fun buildThreeFormats(core: String, code1: String, code2: String): List<String> {
        if (core.startsWith("+")) return listOf(core)
        return listOf(
            "$code1$core",
            "$code2$core",
            "0$core"
        ).distinct()
    }

    private fun isAlreadyCompliant(rawNumbers: List<String>, cores: List<String>, code1: String, code2: String): Boolean {
        if (cores.size != 1) return false
        val core = cores.first()
        val expected = buildThreeFormats(core, code1, code2).toSet()
        val actualCleaned = rawNumbers.map { cleanPhoneString(it) }
        return actualCleaned.size == expected.size && actualCleaned.toSet() == expected
    }

    private fun scanContacts() {
        val code1 = formatCode(etCode1.text.toString())
        val code2 = formatCode(etCode2.text.toString())

        val contactNames = mutableMapOf<Long, String>()
        val contactNumbers = mutableMapOf<Long, MutableList<String>>()

        contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
            null, null, null
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.Contacts._ID)
            val nameIdx = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIdx)
                val name = cursor.getString(nameIdx)?.trim() ?: "بدون اسم"
                contactNames[id] = name
                contactNumbers[id] = mutableListOf()
            }
        }

        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIdx)
                val num = cursor.getString(numIdx)?.trim() ?: continue
                if (num.isNotEmpty()) {
                    contactNumbers[id]?.add(num)
                }
            }
        }

        duplicateGroups.clear()
        multiNumberContacts.clear()
        singleNumberUnformatted.clear()
        skippedCompliantCount = 0

        val allItems = mutableListOf<ContactItem>()
        for ((id, name) in contactNames) {
            val nums = contactNumbers[id] ?: emptyList()
            if (nums.isEmpty()) continue
            val cores = nums.map { extractCoreNumber(it, code1, code2) }.filter { it.isNotEmpty() }.distinct()
            allItems.add(ContactItem(id, name, nums, cores))
        }

        val groupedByName = allItems.groupBy { it.name.replace(Regex("\\s+"), " ").lowercase(Locale.getDefault()) }
        val idsInDuplicates = mutableSetOf<Long>()

        for ((_, list) in groupedByName) {
            if (list.size > 1) {
                duplicateGroups.add(DuplicateGroup(list.first().name, list))
                list.forEach { idsInDuplicates.add(it.contactId) }
            }
        }

        for (item in allItems) {
            if (item.contactId in idsInDuplicates) continue

            if (isAlreadyCompliant(item.rawNumbers, item.distinctCores, code1, code2)) {
                skippedCompliantCount++
                continue
            }

            if (item.distinctCores.size > 1) {
                multiNumberContacts.add(item)
            } else if (item.distinctCores.size == 1) {
                singleNumberUnformatted.add(item)
            }
        }

        tvStats.text = "تم تخطي ($skippedCompliantCount) جهة جاهزة | مكررة: (${duplicateGroups.size}) | متعددة الأرقام: (${multiNumberContacts.size}) | للتوحيد: (${singleNumberUnformatted.size})"
        refreshList()
    }

    private fun refreshList() {
        btnApplyAllSingle.visibility = if (currentTab == 2 && singleNumberUnformatted.isNotEmpty()) View.VISIBLE else View.GONE
        recyclerView.adapter = when (currentTab) {
            0 -> DuplicateAdapter(duplicateGroups)
            1 -> MultiNumberAdapter(multiNumberContacts)
            else -> SingleFormatAdapter(singleNumberUnformatted)
        }
    }

    private fun getRawContactId(contactId: Long): Long? {
        contentResolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID),
            "${ContactsContract.RawContacts.CONTACT_ID}=?",
            arrayOf(contactId.toString()),
            null
        )?.use {
            if (it.moveToFirst()) return it.getLong(0)
        }
        return null
    }

    private fun applyThreeFormatsToContact(contactId: Long, coreNumber: String, code1: String, code2: String): Boolean {
        val rawId = getRawContactId(contactId) ?: return false
        val formats = buildThreeFormats(coreNumber, code1, code2)
        val ops = ArrayList<ContentProviderOperation>()

        ops.add(
            ContentProviderOperation.newDelete(ContactsContract.Data.CONTENT_URI)
                .withSelection(
                    "${ContactsContract.Data.RAW_CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
                    arrayOf(rawId.toString(), ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                ).build()
        )

        for (num in formats) {
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                    .build()
            )
        }

        return try {
            contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun deleteContact(contactId: Long) {
        val uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId)
        contentResolver.delete(uri, null, null)
    }

    private fun renameContact(contactId: Long, newName: String) {
        val rawId = getRawContactId(contactId) ?: return
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(
            ContentProviderOperation.newUpdate(ContactsContract.Data.CONTENT_URI)
                .withSelection(
                    "${ContactsContract.Data.RAW_CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
                    arrayOf(rawId.toString(), ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                )
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, newName)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, newName)
                .build()
        )
        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    private fun mergeDuplicateGroup(group: DuplicateGroup) {
        val code1 = formatCode(etCode1.text.toString())
        val code2 = formatCode(etCode2.text.toString())
        val primary = group.contacts.first()
        val allCores = group.contacts.flatMap { it.distinctCores }.distinct()

        for (i in 1 until group.contacts.size) {
            deleteContact(group.contacts[i].contactId)
        }

        if (allCores.size == 1) {
            applyThreeFormatsToContact(primary.contactId, allCores.first(), code1, code2)
            Toast.makeText(this, "تم الدمج وتطبيق الصيغ الثلاث بنجاح", Toast.LENGTH_SHORT).show()
        } else {
            val rawId = getRawContactId(primary.contactId) ?: return
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newDelete(ContactsContract.Data.CONTENT_URI)
                    .withSelection(
                        "${ContactsContract.Data.RAW_CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
                        arrayOf(rawId.toString(), ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    ).build()
            )
            for (core in allCores) {
                val num = if (core.startsWith("+")) core else "0$core"
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
            }
            contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            Toast.makeText(this, "تم الدمج؛ انتقل لتبويب (أرقام متعددة) لاختيار الرقم الأساسي", Toast.LENGTH_LONG).show()
        }
        scanContacts()
    }

    private fun exportVcfBackup() {
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
            val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
            val file = File(dir, "Contacts_Backup_$timestamp.vcf")
            val sb = StringBuilder()

            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameIdx) ?: ""
                    val num = cursor.getString(numIdx) ?: ""
                    sb.append("BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL:$num\nEND:VCARD\n")
                }
            }
            file.writeText(sb.toString())
            AlertDialog.Builder(this)
                .setTitle("تم حفظ النسخة الاحتياطية")
                .setMessage("المسار:\n${file.absolutePath}")
                .setPositiveButton("موافق", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ في النسخ الاحتياطي: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    inner class DuplicateAdapter(private val items: List<DuplicateGroup>) :
        RecyclerView.Adapter<DuplicateAdapter.VH>() {

        inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(28, 24, 28, 24)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 18) }
            }
            return VH(card)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val group = items[position]
            holder.root.removeAllViews()

            val tvTitle = TextView(this@MainActivity).apply {
                text = "${group.normalizedName} (${group.contacts.size} بطاقات مكررة)"
                textSize = 16f
                setTextColor(0xFF080F13.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            holder.root.addView(tvTitle)

            group.contacts.forEachIndexed { idx, c ->
                val tvSub = TextView(this@MainActivity).apply {
                    text = "• بطاقة ${idx + 1}: ${c.rawNumbers.joinToString(" | ")}"
                    textSize = 13f
                    setTextColor(0xFF455A64.toInt())
                    setPadding(0, 6, 0, 4)
                }
                holder.root.addView(tvSub)
            }

            val btnRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 14, 0, 0)
            }

            val btnMerge = Button(this@MainActivity).apply {
                text = "دمج"
                setBackgroundColor(0xFF0D47A1.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = 8
                }
                setOnClickListener { mergeDuplicateGroup(group) }
            }

            val btnDeleteDup = Button(this@MainActivity).apply {
                text = "حذف المكرر"
                setBackgroundColor(0xFFC62828.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = 8
                }
                setOnClickListener {
                    for (i in 1 until group.contacts.size) {
                        deleteContact(group.contacts[i].contactId)
                    }
                    Toast.makeText(this@MainActivity, "تم الإبقاء على البطاقة الأولى وحذف المكرر", Toast.LENGTH_SHORT).show()
                    scanContacts()
                }
            }

            val btnKeepDistinct = Button(this@MainActivity).apply {
                text = "إبقاء مع تمييز"
                setBackgroundColor(0xFF2E7D32.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
                setOnClickListener {
                    val input = EditText(this@MainActivity).apply {
                        hint = "رمز التمييز (مثلاً: عمل أو رقم)"
                        setText("2")
                    }
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("تمييز الأسماء المتشابهة")
                        .setMessage("سيتم إضافة رمز أو ترقيم تلقائي للبطاقات المكررة لتمييزها:")
                        .setView(input)
                        .setPositiveButton("تطبيق") { _, _ ->
                            val tag = input.text.toString().trim().ifEmpty { "2" }
                            for (i in 1 until group.contacts.size) {
                                val suffix = if (group.contacts.size == 2) " ($tag)" else " ($tag-${i + 1})"
                                renameContact(group.contacts[i].contactId, "${group.contacts[i].name}$suffix")
                            }
                            scanContacts()
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }

            btnRow.addView(btnMerge)
            btnRow.addView(btnDeleteDup)
            btnRow.addView(btnKeepDistinct)
            holder.root.addView(btnRow)
        }
    }

    inner class MultiNumberAdapter(private val items: List<ContactItem>) :
        RecyclerView.Adapter<MultiNumberAdapter.VH>() {

        inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(28, 24, 28, 24)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 18) }
            }
            return VH(card)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.root.removeAllViews()

            val tvName = TextView(this@MainActivity).apply {
                text = item.name
                textSize = 16f
                setTextColor(0xFF080F13.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            holder.root.addView(tvName)

            val radioGroup = RadioGroup(this@MainActivity).apply {
                orientation = RadioGroup.VERTICAL
                setPadding(0, 8, 0, 8)
            }

            var selectedCore = item.distinctCores.first()
            item.distinctCores.forEachIndexed { idx, core ->
                val display = if (core.startsWith("+")) core else "0$core"
                val rb = RadioButton(this@MainActivity).apply {
                    id = View.generateViewId()
                    text = display
                    textDirection = View.TEXT_DIRECTION_LTR
                    gravity = Gravity.CENTER_VERTICAL
                    isChecked = (idx == 0)
                    setOnCheckedChangeListener { _, isChecked ->
                        if (isChecked) selectedCore = core
                    }
                }
                radioGroup.addView(rb)
            }
            holder.root.addView(radioGroup)

            val btnConfirm = Button(this@MainActivity).apply {
                text = "اعتماد الرقم المحدد وحذف الباقي (3 صيغ)"
                setBackgroundColor(0xFF0D47A1.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    val c1 = formatCode(etCode1.text.toString())
                    val c2 = formatCode(etCode2.text.toString())
                    if (applyThreeFormatsToContact(item.contactId, selectedCore, c1, c2)) {
                        Toast.makeText(this@MainActivity, "تم الحفظ بالصيغ الثلاث", Toast.LENGTH_SHORT).show()
                        scanContacts()
                    }
                }
            }
            holder.root.addView(btnConfirm)
        }
    }

    inner class SingleFormatAdapter(private val items: List<ContactItem>) :
        RecyclerView.Adapter<SingleFormatAdapter.VH>() {

        inner class VH(val root: LinearLayout) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(24, 20, 24, 20)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 14) }
            }
            return VH(card)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.root.removeAllViews()

            val infoBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val tvName = TextView(this@MainActivity).apply {
                text = item.name
                textSize = 15f
                setTextColor(0xFF080F13.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val tvNums = TextView(this@MainActivity).apply {
                text = "الحالي: ${item.rawNumbers.joinToString(" | ")}"
                textSize = 12f
                setTextColor(0xFF546E7A.toInt())
            }
            infoBox.addView(tvName)
            infoBox.addView(tvNums)

            val btnFix = Button(this@MainActivity).apply {
                text = "توحيد"
                setBackgroundColor(0xFF2E7D32.toInt())
                setTextColor(0xFFFFFFFF.toInt())
                setOnClickListener {
                    val c1 = formatCode(etCode1.text.toString())
                    val c2 = formatCode(etCode2.text.toString())
                    val core = item.distinctCores.first()
                    if (applyThreeFormatsToContact(item.contactId, core, c1, c2)) {
                        scanContacts()
                    }
                }
            }

            holder.root.addView(infoBox)
            holder.root.addView(btnFix)
        }
    }
}
